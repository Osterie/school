for (let i = -20; i <= 20; i++) {
    if (Math.abs(i) === 13){
        continue
    }
    console.log(i)
}