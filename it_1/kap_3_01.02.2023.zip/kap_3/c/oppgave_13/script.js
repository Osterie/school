for (let i = 0; i <= 333; i++) {
    console.log(i*3)    
}
