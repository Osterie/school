//grunenn til at man bruker "<" istedenfor "<="
//er fordi man begynner å telle fra index 0