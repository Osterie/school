let tall = 0

while (tall <= 50) {
    console.log(tall)
    tall += 1
}