let a = 3;
let b = 7; 

console.log((a != 2) && (b < 10))
console.log((a > 3) && (b === 7))
console.log((a > 2) || (b === 8))
console.log((a === 2) || (b > 8))
console.log(!(b === 10))
console.log(!(b > a))