//a
for (let i = 0; i < 75; i++) {
    console.log("Around the world, around the world")
}

//b

for (let i = 0; i < 74; i++) {

    for (let i = 0; i < 9; i++) {
        console.log("gucci gang")
        
    }
    console.log("spend three racks on new chains")
}