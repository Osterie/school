console.log('\noppgave 2\n')

//a

console.log('2a)')

let a_while = 0
while (a_while <= 100) {
    console.log(a_while)
    a_while += 1
}

//b

let b_while = 0

while (b_while <= 80) {
    console.log(b_while)
    b_while += 8    
}


//c

let c_while = 0

while (c_while < 100) {
    if (c_while % 10 != 0) {
        console.log(c_while)
        
    }
    c_while += 1
}