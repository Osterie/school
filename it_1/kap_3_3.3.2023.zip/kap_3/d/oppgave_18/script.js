//Forklar forskjellen mellom lokale og globale variabler.

//Globale variabler kan brukes i hele scope-en
//lokale kun kan brukes i den lokale scope-en