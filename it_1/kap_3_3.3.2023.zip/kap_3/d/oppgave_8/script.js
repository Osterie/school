function log_cat(){
    console.log("=^.^=");
}

log_cat()