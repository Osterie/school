function areal_sirkel(radius) {
    return Math.PI * radius**2
}

console.log(`areal av en sirkel med radius 5 er: ${areal_sirkel(5)}`)