function siHeiTil(navn) {
    console.log(`Hei ${navn}!`);
}

siHeiTil('Adrian')
siHeiTil('Benjamin')
