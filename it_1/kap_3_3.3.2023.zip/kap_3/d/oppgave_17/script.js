//Hvordan lager vi en lokal variabel?

//vet å deklarere en variabel i et lokalt scope, har vi lagd en lokal variabel
//f.eks ved å deklarere const tall = 4 i en funksjon.