function kvadrat_tall(tall){
    return tall**2
}

console.log(kvadrat_tall(5))