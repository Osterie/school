function areal_sirkel(radius) {
    return Math.PI*radius**2
  }
  
console.log(`arealet til en sirkel med radius 24 er: ${areal_sirkel(24)}`)
console.log(`arealet til en sirkel med radius 32 er: ${areal_sirkel(32)}`)

