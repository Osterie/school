function volum_sirkel(radius) {
    return ( (4/3) * Math.PI * radius**2 )
  }
  
console.log(`volumet til en sirkel med radius 11 er: ${volum_sirkel(11)}`)
console.log(`volumet til en sirkel med radius 21 er: ${volum_sirkel(21)}`)
