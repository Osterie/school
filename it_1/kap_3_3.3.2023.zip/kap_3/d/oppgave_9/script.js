function log_cats(amount){
    for (let i = 0; i < amount; i++) {
        console.log("=^.^=");
    }
}

log_cats(5)