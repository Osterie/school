function sum(a, b){
    return a+b
}

console.log(sum(5, 2))