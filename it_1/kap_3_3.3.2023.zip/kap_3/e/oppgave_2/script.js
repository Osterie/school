const array_numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

for (let i = 0; i < array_numbers.length/2; i++) {
    console.log(array_numbers[i*2])    
}
