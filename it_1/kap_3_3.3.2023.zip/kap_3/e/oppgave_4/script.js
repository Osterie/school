//a tror vi får en feil medling
const tall =  [ 'tre', 4, 'fem', 6, 'syv' ]


//b
console.log(tall.indexOf(10))
console.log(tall.lastIndexOf(10))

//c ja, om den ikke er i array-en returneres -1