/*

Oppgave 1
grunnleggende koding, 4 kodesnapper og fortsette oppgaven eller finne feil


Oppgave 2
OOP, lage ER diagram, Arv, klasse extending 
OOP, sjekk Multipong! eller kanskje Graphical, soundify, meldem_klasse
ER diagram, sjekk ER diagram.png
Klasse extending, sjekk meldem_klasse! er i samme folder som meg.


Oppgave 3
CSV, må kunne legge til enda en CSV og velge om den skal overwrite. 
Data som gjelder 3 sommermåneder, en bedrift som driver utleie virksomhet.

En CSV per måned om hvordan business gikk

Både ha at man kan se hver enkelt måneder og hele sommeren

BRUK NORSK MEDIEBAROMETER SOM START
*/